structure of data
////////////////////////////////////////////////////////
number of vertex	number of edges		capacity

values of profit

values of weight

coefficients related to quadratic term

edges